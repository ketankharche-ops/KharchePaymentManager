# Kharche Payment Manager (Android)

An Android starter project for customer receivables: customer records, installment schedules, local Room database, scheduled notifications, manual WhatsApp reminders, payment recording and CSV reports.

## Important status

This is a source project, not a precompiled APK. Build it in Android Studio. Firebase backup requires you to create/configure your own Firebase project and add `app/google-services.json`.

## Requirements

- Android Studio with Android SDK 36 and JDK 17
- A Firebase project
- Android device running Android 8.0 or newer (minSdk 26)

## 1. Configure Firebase

1. Create a Firebase project at https://console.firebase.google.com/.
2. Add an Android app with package name `in.kharche.paymentmanager`.
3. Download `google-services.json` and place it at `app/google-services.json`.
4. In Firebase Authentication, enable **Anonymous** sign-in.
5. Create a Cloud Firestore database.
6. Publish the included `firestore.rules` rules to Firestore.
7. Reopen/sync the project in Android Studio.

The app creates an anonymous Firebase user on first cloud upload and mirrors newly saved customer and installment records to that user's private Firestore path. Local Room storage remains the primary working database. Upload failures do not block local saves; the starter does not yet include a retry queue.

### Backup limitation to understand

This starter currently performs one-way cloud backup of newly created/updated customer and installment documents. It does not yet implement automatic retry of failed uploads, full two-way reconciliation/restore, account recovery across reinstalls, conflict resolution, or deletion tombstones. Anonymous Firebase identity can be lost if app data is cleared or the app is reinstalled. For durable cross-device recovery, add a real sign-in method (Google/email/phone) and implement two-way sync before production use.

## 2. Build and install

1. Open this folder in Android Studio.
2. Wait for Gradle sync.
3. Connect an Android phone with USB debugging enabled, or create an emulator.
4. Select **Run**.
5. Accept the notification permission prompt on Android 13+.

To create an APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Android Studio will show the generated APK location.

## 3. Using the app

1. Add a customer (name, mobile, project).
2. Go to Payments and tap `+` to add an installment.
3. Select the customer, enter amount, due date/time and reminder date/time.
4. The reminder is scheduled locally using WorkManager.
5. Use **WhatsApp** on a payment row to open WhatsApp with a pre-filled message. Review and tap Send yourself.
6. Use **Record payment** to record full or partial receipts.
7. Export a CSV report from Reports.

Dates in the installment form use `yyyy-MM-dd HH:mm` in the phone's local timezone, for example `2026-12-05 10:30`.

## 4. Android notification behavior

- Grant notification permission when prompted.
- Android/Doze and manufacturer battery controls can delay background work. For critical reminders, exempt the app from aggressive battery optimization on the phone.
- WorkManager is designed for reliable deferrable work, not exact-to-the-second alarms. This project schedules reminders at the selected time but Android may deliver them later under battery restrictions.
- If a payment is fully paid before the reminder runs, the worker checks the local database and suppresses the notification.

## 5. Production checklist

Before using for business-critical accounting:
- Implement Firebase sign-in and two-way sync/recovery.
- Add edit/delete customer screens and payment receipt ledger entries (each partial receipt should be its own immutable transaction).
- Add timezone-safe date/time pickers and validation.
- Add automatic rescheduling after device reboot and after edits (WorkManager persists scheduled work).
- Add backup status, retry queue and sync conflict handling.
- Add encrypted local storage if sensitive customer data requires it.
- Add automated tests, accessibility checks and Play Store signing.
- Verify notification timing on target Android phone models.

## Data model

- `Customer`: name, phone, project/work, notes.
- `Installment`: customer, title, amount in paise, due timestamp, reminder timestamp, paid amount, paid timestamp.
- Currency is stored as integer paise to avoid floating-point accounting errors.

## Privacy

Customer details and payment information are sensitive business records. Keep Firebase rules enabled, do not publish `google-services.json` in a public repository, and do not share exported reports publicly.
