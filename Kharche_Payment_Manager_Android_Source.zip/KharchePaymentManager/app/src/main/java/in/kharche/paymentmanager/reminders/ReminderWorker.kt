package in.kharche.paymentmanager.reminders

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import in.kharche.paymentmanager.R
import in.kharche.paymentmanager.data.AppDatabase
import androidx.room.Room
import java.text.NumberFormat
import java.util.Locale

class ReminderWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val id = inputData.getString("installmentId") ?: return Result.failure()
        val db = Room.databaseBuilder(applicationContext, AppDatabase::class.java, "kharche-payments.db").build()
        val item = db.paymentDao().installment(id) ?: return Result.success()
        if (item.isPaid) return Result.success()
        val customer = db.paymentDao().customer(item.customerId)
        val channelId = "payment_due"
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel(channelId, "Payment reminders", NotificationManager.IMPORTANCE_HIGH))
        }
        val rupees = NumberFormat.getCurrencyInstance(Locale("en", "IN")).format(item.balancePaise / 100.0)
        val notification = NotificationCompat.Builder(applicationContext, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Payment reminder: ${customer?.name ?: "Customer"}")
            .setContentText("${item.title} — $rupees due")
            .setStyle(NotificationCompat.BigTextStyle().bigText("${customer?.name ?: "Customer"}\n${item.title}\nBalance: $rupees"))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        try { NotificationManagerCompat.from(applicationContext).notify(id.hashCode(), notification) }
        catch (_: SecurityException) { /* Android 13+ notification permission may be denied */ }
        return Result.success()
    }
}
