package in.kharche.paymentmanager.sync

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import in.kharche.paymentmanager.data.Customer
import in.kharche.paymentmanager.data.Installment
import kotlinx.coroutines.tasks.await

/**
 * Local-first cloud mirror. Each install receives an anonymous Firebase UID.
 * Add a durable sign-in method before relying on recovery after reinstall/device change.
 */
object CloudSync {
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseFirestore.getInstance() }

    private suspend fun uid(): String {
        auth.currentUser?.let { return it.uid }
        return auth.signInAnonymously().await().user?.uid
            ?: throw IllegalStateException("Firebase anonymous sign-in returned no user")
    }

    suspend fun pushCustomer(c: Customer) {
        val userId = uid()
        db.collection("users").document(userId).collection("customers").document(c.id).set(c).await()
    }

    suspend fun pushInstallment(p: Installment) {
        val userId = uid()
        db.collection("users").document(userId).collection("installments").document(p.id).set(
            mapOf(
                "id" to p.id, "customerId" to p.customerId, "title" to p.title,
                "amountPaise" to p.amountPaise, "dueAt" to p.dueAt, "reminderAt" to p.reminderAt,
                "notes" to p.notes, "paidAmountPaise" to p.paidAmountPaise,
                "paidAt" to p.paidAt, "updatedAt" to p.updatedAt
            )
        ).await()
    }
}
