package in.kharche.paymentmanager.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [Customer::class, Installment::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun paymentDao(): PaymentDao
}
