package in.kharche.paymentmanager

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import androidx.work.WorkManager
import in.kharche.paymentmanager.data.*
import in.kharche.paymentmanager.reminders.AppContext
import in.kharche.paymentmanager.sync.CloudSync
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppContext.init(applicationContext)
        if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        // Firebase anonymous sign-in is performed on first cloud upload.
        val repo = PaymentRepository.get(this)
        setContent { MaterialTheme { PaymentApp(repo) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PaymentApp(repo: PaymentRepository) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val customers by repo.customers.collectAsState(initial = emptyList())
    val installments by repo.installments.collectAsState(initial = emptyList())
    var tab by remember { mutableStateOf(0) }
    var showCustomer by remember { mutableStateOf(false) }
    var showInstallment by remember { mutableStateOf(false) }
    var selectedCustomer by remember { mutableStateOf("") }
    var paymentItem by remember { mutableStateOf<Installment?>(null) }

    val totalDue = installments.sumOf { it.balancePaise }
    val totalPaid = installments.sumOf { it.paidAmountPaise }
    Scaffold(
        topBar = { TopAppBar(title = { Text("Kharche Payment Manager") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = { if (tab == 0) showCustomer = true else showInstallment = true }) {
                Text("+")
            }
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Text("₹") }, label = { Text("Dashboard") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Text("👥") }, label = { Text("Customers") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Text("◷") }, label = { Text("Payments") })
                NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Text("▤") }, label = { Text("Reports") })
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
            when (tab) {
                0 -> {
                    Text("Outstanding balance", style = MaterialTheme.typography.titleMedium)
                    Text(money(totalDue), style = MaterialTheme.typography.headlineLarge)
                    Spacer(Modifier.height(8.dp))
                    Text("Recorded collections: ${money(totalPaid)}")
                    Text("Customers: ${customers.size}   •   Installments: ${installments.size}")
                    Spacer(Modifier.height(16.dp))
                    Text("Upcoming / pending payments", style = MaterialTheme.typography.titleMedium)
                    PaymentList(installments.filter { !it.isPaid }.take(8), customers, onPay = { paymentItem = it },
                        onWhatsApp = { openWhatsApp(context, customers.firstOrNull { c -> c.id == it.customerId }, it) })
                }
                1 -> {
                    Text("Customer records", style = MaterialTheme.typography.titleLarge)
                    LazyColumn { items(customers, key = { it.id }) { c ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Column(Modifier.padding(12.dp)) {
                                Text(c.name, style = MaterialTheme.typography.titleMedium)
                                Text("${c.phone}  •  ${c.project}")
                                Text("Outstanding: ${money(installments.filter { it.customerId == c.id }.sumOf { it.balancePaise })}")
                            }
                        }
                    } }
                }
                2 -> {
                    Text("Installments & payment history", style = MaterialTheme.typography.titleLarge)
                    PaymentList(installments, customers, onPay = { paymentItem = it },
                        onWhatsApp = { openWhatsApp(context, customers.firstOrNull { c -> c.id == it.customerId }, it) })
                }
                3 -> {
                    Text("Collection report", style = MaterialTheme.typography.titleLarge)
                    Text("Total billed: ${money(installments.sumOf { it.amountPaise })}")
                    Text("Total collected: ${money(totalPaid)}")
                    Text("Outstanding: ${money(totalDue)}")
                    Text("Paid installments: ${installments.count { it.isPaid }}")
                    Text("Pending installments: ${installments.count { !it.isPaid }}")
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = {
                        scope.launch {
                            val csv = repo.exportCsv()
                            val file = File(context.cacheDir, "kharche-payment-report.csv")
                            file.writeText(csv)
                            val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "text/csv"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(Intent.createChooser(send, "Export payment report"))
                        }
                    }) { Text("Export CSV report") }
                }
            }
        }
    }

    if (showCustomer) CustomerDialog(onDismiss = { showCustomer = false }) { n, p, project, notes ->
        scope.launch { repo.addCustomer(n, p, project, notes) }; showCustomer = false
    }
    if (showInstallment) InstallmentDialog(customers, onDismiss = { showInstallment = false }) { cid, title, amount, due, reminder, notes ->
        scope.launch { repo.addInstallment(cid, title, amount, due, reminder, notes) }; showInstallment = false
    }
    paymentItem?.let { item ->
        PaymentDialog(item, onDismiss = { paymentItem = null }) { amount ->
            scope.launch { repo.recordPayment(item, amount) }; paymentItem = null
        }
    }
}

@Composable
private fun PaymentList(items: List<Installment>, customers: List<Customer>, onPay: (Installment) -> Unit, onWhatsApp: (Installment) -> Unit) {
    LazyColumn {
        items(items, key = { it.id }) { item ->
            val customer = customers.firstOrNull { it.id == item.customerId }
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text(customer?.name ?: "Customer", style = MaterialTheme.typography.titleMedium)
                    Text("${item.title} • ${money(item.balancePaise)} pending")
                    Text("Due: ${dateTime(item.dueAt)}")
                    if (item.notes.isNotBlank()) Text(item.notes)
                    Row {
                        if (!item.isPaid) TextButton(onClick = { onPay(item) }) { Text("Record payment") }
                        TextButton(onClick = { onWhatsApp(item) }) { Text("WhatsApp") }
                    }
                    if (item.isPaid) Text("PAID • ${dateTime(item.paidAt ?: item.updatedAt)}", color = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

@Composable
private fun CustomerDialog(onDismiss: () -> Unit, onSave: (String,String,String,String) -> Unit) {
    var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }
    var project by remember { mutableStateOf("") }; var notes by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Add customer") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            OutlinedTextField(name, { name = it }, label = { Text("Customer name *") })
            OutlinedTextField(phone, { phone = it }, label = { Text("Mobile number") })
            OutlinedTextField(project, { project = it }, label = { Text("Project / work") })
            OutlinedTextField(notes, { notes = it }, label = { Text("Notes") })
        }
    }, confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = { onSave(name,phone,project,notes) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
private fun InstallmentDialog(customers: List<Customer>, onDismiss: () -> Unit,
                              onSave: (String,String,Long,Long,Long,String) -> Unit) {
    var customerId by remember { mutableStateOf(customers.firstOrNull()?.id ?: "") }
    var title by remember { mutableStateOf("Payment installment") }
    var amount by remember { mutableStateOf("") }
    var dueText by remember { mutableStateOf("2026-12-01 10:00") }
    var reminderText by remember { mutableStateOf("2026-12-01 09:00") }
    var notes by remember { mutableStateOf("") }
    val formatter = remember { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Add installment") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            if (customers.isEmpty()) Text("Add a customer first.")
            else {
                Text("Customer")
                customers.forEach { c ->
                    Row { RadioButton(customerId == c.id, { customerId = c.id }); Text(c.name, Modifier.padding(top = 12.dp)) }
                }
                OutlinedTextField(title, { title = it }, label = { Text("Installment / work") })
                OutlinedTextField(amount, { amount = it }, label = { Text("Amount in ₹") })
                OutlinedTextField(dueText, { dueText = it }, label = { Text("Due date/time (yyyy-MM-dd HH:mm)") })
                OutlinedTextField(reminderText, { reminderText = it }, label = { Text("Reminder date/time (yyyy-MM-dd HH:mm)") })
                OutlinedTextField(notes, { notes = it }, label = { Text("Notes") })
            }
        }
    }, confirmButton = {
        TextButton(enabled = customers.isNotEmpty() && amount.toDoubleOrNull() != null, onClick = {
            val due = formatter.parse(dueText)?.time
            val rem = formatter.parse(reminderText)?.time
            if (due != null && rem != null && amount.toDouble() > 0) onSave(customerId,title,(amount.toDouble()*100).toLong(),due,rem,notes)
        }) { Text("Save & schedule") }
    }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
private fun PaymentDialog(item: Installment, onDismiss: () -> Unit, onSave: (Long) -> Unit) {
    var amount by remember { mutableStateOf((item.balancePaise / 100.0).toString()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Record received payment") }, text = {
        Column {
            Text("Balance: ${money(item.balancePaise)}")
            OutlinedTextField(amount, { amount = it }, label = { Text("Received amount ₹") })
        }
    }, confirmButton = {
        TextButton(enabled = (amount.toDoubleOrNull() ?: 0.0) > 0, onClick = {
            onSave(((amount.toDoubleOrNull() ?: 0.0)*100).toLong())
        }) { Text("Record") }
    }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

private fun openWhatsApp(context: android.content.Context, customer: Customer?, item: Installment) {
    val phone = customer?.phone?.filter { it.isDigit() }.orEmpty()
    val message = "Hello ${customer?.name ?: "Customer"}, this is a payment reminder for ${item.title}. Amount pending: ${money(item.balancePaise)}. Due date: ${dateTime(item.dueAt)}. Thank you."
    val url = if (phone.isNotBlank()) "https://wa.me/$phone?text=${Uri.encode(message)}" else "https://wa.me/?text=${Uri.encode(message)}"
    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
}
private fun money(paise: Long) = "₹%,.2f".format(Locale("en", "IN"), paise / 100.0)
private fun dateTime(ms: Long) = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(ms))
