package in.kharche.paymentmanager.reminders

import androidx.work.*
import in.kharche.paymentmanager.data.Installment
import java.util.concurrent.TimeUnit

object ReminderScheduler {
    fun schedule(item: Installment) {
        val delay = (item.reminderAt - System.currentTimeMillis()).coerceAtLeast(0)
        val request = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(workDataOf("installmentId" to item.id))
            .build()
        WorkManager.getInstance(AppContext.context).enqueueUniqueWork(
            "payment-reminder-${item.id}", ExistingWorkPolicy.REPLACE, request
        )
    }
    fun cancel(id: String) {
        WorkManager.getInstance(AppContext.context).cancelUniqueWork("payment-reminder-$id")
    }
}
