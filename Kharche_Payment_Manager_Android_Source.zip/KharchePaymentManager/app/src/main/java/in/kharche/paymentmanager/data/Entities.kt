package in.kharche.paymentmanager.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey val id: String,
    val name: String,
    val phone: String,
    val project: String,
    val notes: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "installments")
data class Installment(
    @PrimaryKey val id: String,
    val customerId: String,
    val title: String,
    val amountPaise: Long,
    val dueAt: Long,
    val reminderAt: Long,
    val notes: String = "",
    val paidAmountPaise: Long = 0,
    val paidAt: Long? = null,
    val updatedAt: Long = System.currentTimeMillis()
) {
    val balancePaise: Long get() = (amountPaise - paidAmountPaise).coerceAtLeast(0)
    val isPaid: Boolean get() = balancePaise == 0L
}
