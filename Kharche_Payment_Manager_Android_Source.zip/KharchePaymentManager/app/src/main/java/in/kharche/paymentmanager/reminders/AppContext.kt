package in.kharche.paymentmanager.reminders

import android.content.Context

object AppContext {
    lateinit var context: Context
        private set
    fun init(context: Context) { this.context = context.applicationContext }
}
