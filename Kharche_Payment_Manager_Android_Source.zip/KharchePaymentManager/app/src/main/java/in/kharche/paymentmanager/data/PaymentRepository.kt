package in.kharche.paymentmanager.data

import android.content.Context
import androidx.room.Room
import in.kharche.paymentmanager.reminders.ReminderScheduler
import in.kharche.paymentmanager.sync.CloudSync
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class PaymentRepository private constructor(context: Context) {
    private val db = Room.databaseBuilder(context, AppDatabase::class.java, "kharche-payments.db").build()
    private val dao = db.paymentDao()
    val customers: Flow<List<Customer>> = dao.customers()
    val installments: Flow<List<Installment>> = dao.installments()

    suspend fun addCustomer(name: String, phone: String, project: String, notes: String) {
        val c = Customer(UUID.randomUUID().toString(), name.trim(), phone.trim(), project.trim(), notes.trim())
        dao.saveCustomer(c)
        runCatching { CloudSync.pushCustomer(c) }
    }

    suspend fun addInstallment(customerId: String, title: String, amountPaise: Long, dueAt: Long, reminderAt: Long, notes: String) {
        val item = Installment(UUID.randomUUID().toString(), customerId, title.trim(), amountPaise, dueAt, reminderAt, notes.trim())
        dao.saveInstallment(item)
        ReminderScheduler.schedule(item)
        runCatching { CloudSync.pushInstallment(item) }
    }

    suspend fun recordPayment(item: Installment, amountPaise: Long) {
        val now = System.currentTimeMillis()
        dao.addPayment(item.id, amountPaise, now)
        dao.installment(item.id)?.let {
            ReminderScheduler.cancel(it.id)
            runCatching { CloudSync.pushInstallment(it) }
        }
    }

    suspend fun deleteInstallment(id: String) {
        ReminderScheduler.cancel(id)
        dao.deleteInstallment(id)
    }

    suspend fun exportCsv(): String {
        val cs = dao.allCustomers().associateBy { it.id }
        val rows = dao.allInstallments().sortedBy { it.dueAt }
        return buildString {
            appendLine("Customer,Phone,Project,Installment,Amount INR,Paid INR,Balance INR,Due date,Status,Notes")
            rows.forEach { p ->
                val c = cs[p.customerId]
                fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
                appendLine(listOf(q(c?.name.orEmpty()), q(c?.phone.orEmpty()), q(c?.project.orEmpty()), q(p.title),
                    "%.2f".format(p.amountPaise / 100.0), "%.2f".format(p.paidAmountPaise / 100.0),
                    "%.2f".format(p.balancePaise / 100.0), q(java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date(p.dueAt))),
                    q(if (p.isPaid) "Paid" else "Pending"), q(p.notes)).joinToString(","))
            }
        }
    }

    companion object {
        @Volatile private var INSTANCE: PaymentRepository? = null
        fun get(context: Context): PaymentRepository = INSTANCE ?: synchronized(this) {
            INSTANCE ?: PaymentRepository(context.applicationContext).also { INSTANCE = it }
        }
    }
}
