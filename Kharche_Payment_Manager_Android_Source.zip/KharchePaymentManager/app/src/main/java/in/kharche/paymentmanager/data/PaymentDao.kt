package in.kharche.paymentmanager.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PaymentDao {
    @Query("SELECT * FROM customers ORDER BY name COLLATE NOCASE")
    fun customers(): Flow<List<Customer>>

    @Query("SELECT * FROM installments ORDER BY dueAt")
    fun installments(): Flow<List<Installment>>

    @Query("SELECT * FROM customers WHERE id = :id LIMIT 1")
    suspend fun customer(id: String): Customer?

    @Query("SELECT * FROM installments WHERE id = :id LIMIT 1")
    suspend fun installment(id: String): Installment?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveCustomer(customer: Customer)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveInstallment(installment: Installment)

    @Query("UPDATE installments SET paidAmountPaise = MIN(amountPaise, paidAmountPaise + :amount), paidAt = :paidAt, updatedAt = :paidAt WHERE id = :id")
    suspend fun addPayment(id: String, amount: Long, paidAt: Long)

    @Query("DELETE FROM installments WHERE id = :id")
    suspend fun deleteInstallment(id: String)

    @Query("DELETE FROM customers WHERE id = :id")
    suspend fun deleteCustomer(id: String)

    @Query("SELECT * FROM customers")
    suspend fun allCustomers(): List<Customer>

    @Query("SELECT * FROM installments")
    suspend fun allInstallments(): List<Installment>
}
